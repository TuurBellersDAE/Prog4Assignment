#pragma once
#include "RenderComponent.h"

class RenderTexture2DComponent : public RenderComponent
{
};

